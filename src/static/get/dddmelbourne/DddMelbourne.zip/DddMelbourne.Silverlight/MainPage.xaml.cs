﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ServiceModel;
using DddMelbourne.Silverlight.EventService;

namespace DddMelbourne.Silverlight
{
    public partial class MainPage : UserControl
    {
        private EventServiceClient client;
        public MainPage()
        {
            InitializeComponent();
            client = new EventServiceClient();
            client.GetEventsCompleted += new EventHandler<GetEventsCompletedEventArgs>(client_GetEventsCompleted);
            LoadNewDate();
        }

        private void EventsCalendar_SelectedDatesChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadNewDate();
        }

        void client_GetEventsCompleted(object sender, GetEventsCompletedEventArgs e)
        {

            this.Header.Text += "And the event is done";
        }

        private void LoadNewDate()
        {
            var date = EventsCalendar.SelectedDate ?? DateTime.Now;
            this.Header.Text = "Showing events for: " + date.ToString("dd/MM/yyyy");
            client.GetEventsAsync(date);
        }
    }
}
