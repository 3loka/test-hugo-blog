﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DddMelbourne.Data.Models;
using System.ServiceModel.Activation;

namespace DddMelbourne.Data.Services
{
    internal class EventService : IEventService
    {
        private IDddMelbourneDataContext ctx;

        public EventService(IDddMelbourneDataContext ctx)
        {
            this.ctx = ctx;
        }

        #region IEventService Members

        public IEnumerable<ICWS_EventItem> GetEvents(DateTime date)
        {
            return ctx
                .CWS_EventItems
                .Where(x => x.EventDate.Date == date);

            //return from eventItem in ctx.CWS_EventItems
            //       where eventItem.EventDate.Date == date
            //       select eventItem;
        }

        #endregion
    }
}
