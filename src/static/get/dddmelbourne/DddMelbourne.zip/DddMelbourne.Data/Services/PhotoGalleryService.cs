﻿using System.Linq;
using DddMelbourne.Data.Models;

namespace DddMelbourne.Data.Services
{
    internal class PhotoGalleryService : IPhotoGalleryService
    {
        private IDddMelbourneDataContext ctx;

        public PhotoGalleryService(IDddMelbourneDataContext ctx)
        {
            this.ctx = ctx;
        }

        #region IPhotoGalleryService Members

        public ICWS_Galleries GetGallery(int id)
        {
            return ctx.CWS_Galleriess.SingleOrDefault(x => x.Id == id);
        }

        #endregion
    }
}
