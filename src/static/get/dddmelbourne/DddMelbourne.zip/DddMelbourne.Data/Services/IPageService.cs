﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using umbraco.Linq.Core;
using Examine;
using Examine.Providers;

namespace DddMelbourne.Data.Services
{
    public interface IPageService
    {
        IEnumerable<DocTypeBase> GetNewsAndEventItems(int parentId);

        ISearchResults Search(string searchTerm);
    }
}
