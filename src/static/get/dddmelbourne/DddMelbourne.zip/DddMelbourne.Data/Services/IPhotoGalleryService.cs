﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DddMelbourne.Data.Models;

namespace DddMelbourne.Data.Services
{
    public interface IPhotoGalleryService
    {
        ICWS_Galleries GetGallery(int id);
    }
}
