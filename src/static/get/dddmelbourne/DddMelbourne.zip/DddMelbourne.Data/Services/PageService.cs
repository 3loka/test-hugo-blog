﻿using System.Collections.Generic;
using System.Linq;
using DddMelbourne.Data.Models;
using Examine;
using Examine.Providers;
using Examine.SearchCriteria;
using umbraco.Linq.Core;

namespace DddMelbourne.Data.Services
{
    internal class PageService : IPageService
    {
        private IDddMelbourneDataContext ctx;
        private BaseSearchProvider searchProvider;

        public PageService(IDddMelbourneDataContext ctx, BaseSearchProvider searchProvider)
        {
            this.ctx = ctx;
            this.searchProvider = searchProvider;
        }

        #region IPageService Members

        public IEnumerable<DocTypeBase> GetNewsAndEventItems(int parentId)
        {
            var items = ctx
                .CWS_NewsEventsLists
                .Single(x => x.Id == parentId).Children;
            return items
                .OrderBy(x => x.SortOrder);

            //alternatively we can do a context-wide query
            //var items = ctx
            //    .CWS_EventItems
            //    .Where(x => x.ParentNodeId == parentId)
            //    .OfType<DocTypeBase>();
            //items = items
            //    .Concat(
            //        ctx
            //        .CWS_NewsItems
            //        .Where(x => x.ParentNodeId == parentId)
            //        .OfType<DocTypeBase>()
            //    );

            //or finally you could do the above with Examine (but you'd need a different return type ;)
            //var sc = this.searchProvider.CreateSearchCriteria(IndexType.Content);
            //sc = sc.GroupedOr(new[] { "nodeTypeAlias", "nodeTypeAlias" }, "CWS_EventItem", "CWS_NewsItem")
            //    .And()
            //    .ParentId(parentId)
            //    .Compile();
            //return this.searchProvider.Search(sc);
        }

        public ISearchResults Search(string searchTerm)
        {
            //create a fluent API search object
            //since we want everything to be an OR condition we need to explicitly state it
            //by default the first inclusion is AND
            var sc = this.searchProvider.CreateSearchCriteria(IndexType.Content);
            sc = sc
                .GroupedOr(new[] { "nodeName", "bodyText" }, searchTerm)
                .Compile();

            //produces a Lucene query like this:
            //+(nodeName:<searchTest> metaKeywords:<searchText> metaDescription:<searchText> bodyText:<searchText>) +IndexType:content
            var results = this.searchProvider.Search(sc);
            return results;
        }

        #endregion
    }
}
