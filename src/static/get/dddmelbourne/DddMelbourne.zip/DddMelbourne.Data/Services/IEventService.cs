﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DddMelbourne.Data.Models;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;

namespace DddMelbourne.Data.Services
{
    public interface IEventService
    {
        IEnumerable<ICWS_EventItem> GetEvents(DateTime date);
    }
}
