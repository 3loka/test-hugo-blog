﻿using System;
using System.Collections.Generic;
using DddMelbourne.Data.Models;
using DddMelbourne.Data.Services;
using DddMelbourne.Mvp.Models;
using DddMelbourne.Mvp.Presenters;
using DddMelbourne.Mvp.Views;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Rhino.Mocks;

namespace DddMelbourne.Tests
{
    [TestClass]
    public class ListGalleriesPresenterTests
    {
       [TestMethod]
        public void ListGalleries_SSort_Order_Dictated_By_Property()
        {
            //Arrange
            var service = MockRepository.GenerateMock<IPhotoGalleryService>();
            ICWS_Galleries galleries = MockRepository.GenerateMock<ICWS_Galleries>();
            galleries.Expect(x => x.SortBy).Return("createDate");
            galleries.Expect(x => x.SortOrder).Return("ascending");
            galleries.Expect(x => x.CWS_Gallerys).Return(new List<ICWS_Gallery>()).Repeat.Any();
            service.Expect(x => x.GetGallery(Arg<int>.Is.Anything)).Return(galleries).Repeat.Any();

            var view = MockRepository.GenerateMock<IListGalleriesView>();
            view.Expect(x => x.PageId).Return(0).Repeat.Any();
            var model = new GalleryModel();
            view.Expect(x => x.Model).Return(model).Repeat.Any();

            var presenter = new ListGalleriesPresenter(view, service);

            //Act
            view.Raise(x => x.Load += null, this, EventArgs.Empty);
            presenter.ReleaseView();

            //Assert
            service.VerifyAllExpectations();
            galleries.VerifyAllExpectations();
            view.VerifyAllExpectations();
        }
    }
}
