﻿using System;
using DddMelbourne.Data.Services;
using DddMelbourne.Mvp.Views;
using WebFormsMvp;

namespace DddMelbourne.Mvp.Presenters
{
    public class NewsEventsPresenter : Presenter<INewsEventsView>
    {
        private IPageService service;

        public NewsEventsPresenter(INewsEventsView view, IPageService service)
            : base(view)
        {
            this.service = service;
            this.View.Load += new EventHandler(View_Load);
        }

        void View_Load(object sender, EventArgs e)
        {
            this.View.Model.Items = this.service.GetNewsAndEventItems(this.View.PageId);
        }

        public override void ReleaseView()
        {
        }
    }
}
