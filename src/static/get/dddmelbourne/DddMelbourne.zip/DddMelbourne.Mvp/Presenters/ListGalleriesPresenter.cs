﻿using System;
using System.Linq;
using DddMelbourne.Data.Services;
using DddMelbourne.Mvp.Views;
using WebFormsMvp;

namespace DddMelbourne.Mvp.Presenters
{
    public class ListGalleriesPresenter : Presenter<IListGalleriesView>
    {
        private IPhotoGalleryService galleryService;

        public ListGalleriesPresenter(IListGalleriesView view, IPhotoGalleryService galleryService)
            : base(view)
        {
            this.galleryService = galleryService;
            this.View.Load += new EventHandler(View_Load);
        }

        void View_Load(object sender, EventArgs e)
        {
            var gallery = galleryService.GetGallery(this.View.PageId);

            var sortOrder = gallery.SortOrder;
            var sortBy = gallery.SortBy;

            if (sortOrder.ToUpper() == "ASCENDING")
                this.View.Model.Gallery = gallery.CWS_Gallerys.OrderBy(x => sortBy == "createDate" ? x.CreateDate : x.UpdateDate);
            else
                this.View.Model.Gallery = gallery.CWS_Gallerys.OrderByDescending(x => sortBy == "createDate" ? x.CreateDate : x.UpdateDate);
        }

        public override void ReleaseView()
        {
           
        }
    }
}
