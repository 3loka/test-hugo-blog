﻿using System;
using System.Linq;
using DddMelbourne.Data.Services;
using DddMelbourne.Mvp.Models;
using WebFormsMvp;
using Examine;
using System.Collections.Generic;

namespace DddMelbourne.Mvp.Presenters
{
    public class SearchPresenter : Presenter<IView<SearchModel>>
    {
        private IPageService service;
        public SearchPresenter(IView<SearchModel> view, IPageService service)
            : base(view)
        {
            this.service = service;
            this.View.Load += new EventHandler(View_Load);
        }

        void View_Load(object sender, EventArgs e)
        {
            string searchTerm = Request.QueryString["search"];
            if (string.IsNullOrEmpty(searchTerm))
            {
                this.View.Model.SearchResults = new List<SearchResult>();
            }
            else
            {
                var results = this.service.Search(searchTerm);
                var pageNumber = 0;
                int.TryParse(Request.QueryString["page"], out pageNumber);

                this.View.Model.SearchResults = results.Skip(pageNumber).Take(5); 
            }
        }

        public override void ReleaseView()
        {
        }
    }
}
