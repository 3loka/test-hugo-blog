﻿using DddMelbourne.Mvp.Models;
using WebFormsMvp;

namespace DddMelbourne.Mvp.Views
{
    public interface IListGalleriesView : IView<GalleryModel>
    {
        int PageId { get; set; }
    }
}
