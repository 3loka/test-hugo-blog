﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Examine;

namespace DddMelbourne.Mvp.Models
{
    public class SearchModel
    {
        public IEnumerable<SearchResult> SearchResults { get; set; }
    }
}
