﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using umbraco.Linq.Core;

namespace DddMelbourne.Mvp.Models
{
    public class NewsEventsModel
    {
        public IEnumerable<DocTypeBase> Items { get; set; }
    }
}
