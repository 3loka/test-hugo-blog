﻿using System.Collections.Generic;
using DddMelbourne.Data.Models;

namespace DddMelbourne.Mvp.Models
{
    public class GalleryModel
    {
        public IEnumerable<ICWS_Gallery> Gallery { get; set; }
    }
}
