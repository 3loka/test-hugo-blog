﻿using System.Linq;
using umbraco.BusinessLogic;
using umbraco.cms.businesslogic.web;
using umbraco.cms.presentation.Trees;
using umbraco;
using System;

namespace DddMelbourne
{
    public class UmbracoEventHandlers : ApplicationBase
    {
        public UmbracoEventHandlers()
        {
            loadContent.AfterTreeRender += 
                new EventHandler<TreeEventArgs>(loadContent_AfterTreeRender);
        }

        void loadContent_AfterTreeRender(object sender, TreeEventArgs e)
        {
            var docs = sender as Document[];
            if (docs != null && docs[0].ContentType.Alias == "CWS_Photo")
                e
                    .Tree
                    .treeCollection = e.Tree.treeCollection.OrderBy(x => x.Text).ToList();
        }
    }
}