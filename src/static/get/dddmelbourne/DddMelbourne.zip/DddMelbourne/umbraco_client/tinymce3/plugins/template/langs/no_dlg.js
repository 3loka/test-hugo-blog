tinyMCE.addI18n('no.template_dlg',{
title:"Maler",
label:"Mal",
desc_label:"Omtale",
desc:"Sett inn forh\u00E5ndsdefinert malinnhold",
select:"Velg en mal",
preview:"Forh\u00E5ndsvis",
warning:"Advarsel: Utskifting av en mal med en annen kan f\u00F8re til at data g\u00E5r tapt.",
mdate_format:"%d-%m-%Y %H:%M:%S",
cdate_format:"%d-%m-%Y %H:%M:%S",
months_long:"januar,februar,mars,april,mai,juni,juli,august,september,oktober,november,desember",
months_short:"jan,feb,mar,apr,mai,jun,jul,aug,sep,okt,nov,des",
day_long:"s\u00F8ndag,mandag,tirsdag,onsdag,torsdag,fredag,l\u00F8rdag,s\u00F8ndag",
day_short:"s\u00F8n,man,tir,ons,tor,fre,l\u00F8r,s\u00F8n"
});