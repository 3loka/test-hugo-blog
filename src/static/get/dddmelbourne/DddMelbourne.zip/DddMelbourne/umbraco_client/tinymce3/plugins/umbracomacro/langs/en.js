tinyMCE.addI18n('en.umbracomacro',{
    desc : 'Insert macro'
});
