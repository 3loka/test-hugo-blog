﻿/********************* Live Editing CreateModule functions *********************/
function CreateModuleOk()
{
    UmbracoCommunicator.SendClientMessage('createcontent', '');
}