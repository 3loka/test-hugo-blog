﻿/********************* Live Editing DeleteModule functions *********************/
function DeleteModuleOk()
{
    UmbracoCommunicator.SendClientMessage('deletecontent', '');
}
