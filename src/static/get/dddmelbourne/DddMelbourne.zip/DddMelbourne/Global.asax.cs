﻿using System;
using System.Web;
using Autofac;
using Autofac.Integration.Web;
using DddMelbourne.Data.Services;
using DddMelbourne.Mvp.Presenters;
using Examine;
using Examine.Providers;
using umbraco.Linq.Core;
using umbraco.presentation;
using WebFormsMvp.Contrib.Autofac;

namespace DddMelbourne
{
    public class Global : umbraco.Global, IContainerProviderAccessor
    {
        static IContainerProvider _containerProvider;

        protected override void Application_Start(object sender, EventArgs e)
        {
            var builder = new ContainerBuilder();

            builder.Register(x => new HttpContextWrapper(HttpContext.Current))
                .As<HttpContextBase>();

            builder.RegisterAssemblyTypes(typeof(IEventService).Assembly)
                .Where(x => x.FullName.EndsWith("Service") || typeof(IUmbracoDataContext).IsAssignableFrom(x))
                .AsImplementedInterfaces();

            builder.Register(x => UmbracoContext.Current.InPreviewMode ? ExamineManager.Instance.SearchProviderCollection["InternalSearch"] : ExamineManager.Instance.SearchProviderCollection["CWSIndex"])
                .As<BaseSearchProvider>();

            //how to check for preview in 4.0.x
            //builder.Register(x => !string.IsNullOrEmpty(HttpContext.Current.Request["umbVersion"]) ? ExamineManager.Instance.SearchProviderCollection["InternalSearch"] : ExamineManager.Instance.SearchProviderCollection["CWSIndex"])
            //    .As<BaseSearchProvider>();

            //builder.RegisterType<IEventService>();

            builder.RegisterPresenters(typeof(SearchPresenter).Assembly);

            IContainer container = builder.Build();
            _containerProvider = new ContainerProvider(container);
            WebFormsMvp.Binder.PresenterBinder.Factory = new AutofacPresenterFactory(_containerProvider);
        }

        public IContainerProvider ContainerProvider
        {
            get { return _containerProvider; }
        }
    }
}