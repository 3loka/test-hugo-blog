﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;
using Autofac;
using Autofac.Integration.Web;
using DddMelbourne.Data.Models;
using DddMelbourne.Data.Services;

namespace DddMelbourne
{
    /// <summary>
    /// Summary description for EventService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [ScriptService]
    public class EventService : System.Web.Services.WebService
    {
        [WebMethod]
        [ScriptMethod]
        public IEnumerable<ICWS_EventItem> GetEvents(DateTime date)
        {
            var eventService = ((IContainerProviderAccessor)HttpContext.Current.ApplicationInstance).ContainerProvider.RequestLifetime.Resolve<IEventService>();

            return eventService.GetEvents(date);
        }
    }
}
