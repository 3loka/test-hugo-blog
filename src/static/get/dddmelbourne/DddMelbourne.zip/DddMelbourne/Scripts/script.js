//When the DOM tree is loaded
$(document).ready(function() {

    //Add pointer class to .photo .item
    $(".photo .item").addClass("pointer");

    //Hover over photo fade in hidden span
    $(".photo .item").hover(
        function() {
            $(this).find("span").fadeIn();
        },
        function() {
            $(this).find("span").fadeOut();
        }
    );

        //setup defaults for jQuery AJAX
        $.ajaxSetup({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            data: "{}",
            dataFilter: function (data) {
                var msg;

                if (typeof (JSON) !== 'undefined' && typeof (JSON.parse) === 'function')
                    msg = JSON.parse(data);
                else
                    msg = eval('(' + data + ')');

                if (msg.hasOwnProperty('d'))
                    return msg.d;
                else
                    return msg;
            }
        });
});

